Mission Rewards Overhaul v.1xx for X4 Foundations

By Arronicus (Arronicus#5691 on discord)


Installation instructions:

Extract contents into Extenstions folder in X4 folder where your X4.exe file is. (Not in documents/egosoft)


Permissions:

Modders wishing to use this mod or any portion of it in their own packs or mods must credit Arronicus



What this mod does:

- Alters formula for modification of mission credit rewards based on faction standings, to make standings more meaningful, including at lower levels.

- Scales up impact of faction standings on missions dramatically, to make missions a more viable income source even into mid and late game.

- Adjusts payouts of many lower-paying missions to be more worthwhile to run

- Adjusts down Station building missions to bring them in line with other missions

- Brings Rare and Exceptional modparts up to reasonable reward rates from missions (4% and 2% respectively instead of the 0.12% and 0.08% vanilla values )


Possible conflicts:

Other missions that modify mission rewards through MD, like The Teleportation Wars



Savegame safety:

This mod presently adds no new content. Save files should be safe, but backing up save files before playing with new mods is always reccomended. 


Troubleshooting tips:

Q. Will Mission Rewards Overhaul make my game lag?
  A. M.R.O. should have no effect on game performance, including presently only generating the usual debug logs all mods generate (unsigned files)

Q. My game doesn't start up with your extension enabled!
  A. Disable Mission Rewards Overhaul in your extensions list and nothing else. Does your game now load? If no, then M.R.O. is likely not the problem.
     If yes, you may be running another extension that conflicts with mine.

Q. Mission Rewards Overhaul is definitely making my game lag!
  A. Is it though? Please send me your debug log if so, and time permitting, I'll try to identify the issue. 

Credits:

A big thank you to the members of the x4_modding channel on the unofficial egosoft discord: https://discord.gg/J8u6Kdc
Especially SirNukes, for troubleshooting his X4 Customizer tool with me, without which I might have died of frustration making this mod trying to 
troubleshoot errors.